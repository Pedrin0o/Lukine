// products.js - Gerenciamento de produtos e carrinho

// Referências globais
let products = [];
let cart = []; // Agora o carrinho será carregado do Firestore
let favorites = []; // Agora os favoritos serão carregados do Firestore

// Carrega produtos do Firestore
function loadProducts() {
  db.collection("products").orderBy('createdAt', 'desc').get() // Ordena por data de criação
    .then((querySnapshot) => {
      products = [];
      querySnapshot.forEach((doc) => {
        products.push({
          id: doc.id,
          ...doc.data()
        });
      });
      renderFeaturedProducts();
      renderAllProducts(); // Renderiza todos os produtos se houver um container para eles
    })
    .catch((error) => {
      console.error("Erro ao carregar produtos:", error);
      showError("Erro ao carregar produtos: " + getFirebaseError(error.code));
    });
}

// Renderiza produtos em destaque
function renderFeaturedProducts() {
  const featuredContainer = document.getElementById('featured-products');
  if (!featuredContainer) return;

  featuredContainer.innerHTML = '';

  const featuredProducts = products.filter(p => p.featured).slice(0, 4); // Limita a 4 produtos em destaque

  if (featuredProducts.length === 0) {
    featuredContainer.innerHTML = '<p class="no-products-message">Nenhum produto em destaque no momento.</p>';
    return;
  }

  featuredProducts.forEach(product => {
    const isFavorite = favorites.includes(product.id);
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    productCard.innerHTML = `
      <img src="${product.images[0] || 'https://via.placeholder.com/150'}" alt="${product.name}">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p class="product-price">R$ ${product.price.toFixed(2)}</p>
        <div class="product-actions">
          <button class="add-to-cart primary-button" data-id="${product.id}">Adicionar ao Carrinho</button>
          <button class="favorite-btn ${isFavorite ? 'active' : ''}" data-id="${product.id}">
            <i class="${isFavorite ? 'fas' : 'far'} fa-heart"></i>
          </button>
        </div>
      </div>
    `;
    featuredContainer.appendChild(productCard);
  });

  attachProductCardEvents();
}

// Renderiza todos os produtos (para uma página de produtos completa)
function renderAllProducts() {
  const allProductsContainer = document.getElementById('all-products-list'); // Assuma que você tem um div com esse ID
  if (!allProductsContainer) return;

  allProductsContainer.innerHTML = '';

  if (products.length === 0) {
    allProductsContainer.innerHTML = '<p class="no-products-message">Nenhum produto disponível no momento.</p>';
    return;
  }

  products.forEach(product => {
    const isFavorite = favorites.includes(product.id);
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    productCard.innerHTML = `
      <img src="${product.images[0] || 'https://via.placeholder.com/150'}" alt="${product.name}">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p class="product-category">Categoria: ${product.category}</p>
        <p class="product-price">R$ ${product.price.toFixed(2)}</p>
        <div class="product-actions">
          <button class="add-to-cart primary-button" data-id="${product.id}">Adicionar ao Carrinho</button>
          <button class="favorite-btn ${isFavorite ? 'active' : ''}" data-id="${product.id}">
            <i class="${isFavorite ? 'fas' : 'far'} fa-heart"></i>
          </button>
        </div>
      </div>
    `;
    allProductsContainer.appendChild(productCard);
  });

  attachProductCardEvents();
}

// Função para anexar eventos aos botões (reutilizável)
function attachProductCardEvents() {
  // Remove listeners antigos primeiro para evitar duplicação
  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.replaceWith(btn.cloneNode(true));
  });
  
  document.querySelectorAll('.favorite-btn').forEach(btn => {
    btn.replaceWith(btn.cloneNode(true));
  });

  // Adiciona novos listeners
  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', addToCart);
  });

  document.querySelectorAll('.favorite-btn').forEach(btn => {
    btn.addEventListener('click', toggleFavorite);
  });
}

// Adiciona produto ao carrinho (função corrigida)
async function addToCart(e) {
  const productId = e.currentTarget.getAttribute('data-id');
  const user = auth.currentUser;

  if (!user) {
    showError('Por favor, faça login para adicionar itens ao carrinho.');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1500);
    return;
  }

  const userCartRef = db.collection('userData').doc(user.uid);

  try {
    await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(userCartRef);
      const userData = doc.data() || {};
      const currentCart = userData.cart || [];
      
      const itemIndex = currentCart.findIndex(item => item.productId === productId);

      if (itemIndex >= 0) {
        currentCart[itemIndex].quantity += 1;
      } else {
        currentCart.push({
          productId,
          quantity: 1
        });
      }

      transaction.set(userCartRef, {
        cart: currentCart
      }, { merge: true });
    });

    showSuccess('Produto adicionado ao carrinho!');
    loadUserData(user.uid);
  } catch (error) {
    console.error('Erro ao adicionar ao carrinho:', error);
    showError('Erro ao adicionar ao carrinho: ' + getFirebaseError(error.code));
  }
}

// Alterna favorito
async function toggleFavorite(e) {
  const productId = e.currentTarget.getAttribute('data-id');
  const user = auth.currentUser;

  if (!user) {
    showError('Por favor, faça login para favoritar produtos.');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1500);
    return;
  }

  const userFavoritesRef = db.collection('userData').doc(user.uid);

  try {
    await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(userFavoritesRef);
      const userData = doc.data() || {};
      let currentFavorites = userData.favorites || [];
      const heartIcon = e.currentTarget.querySelector('i');

      const favIndex = currentFavorites.indexOf(productId);

      if (favIndex >= 0) {
        currentFavorites.splice(favIndex, 1);
        heartIcon.className = 'far fa-heart';
        e.currentTarget.classList.remove('active');
        showSuccess('Produto removido dos favoritos!');
      } else {
        currentFavorites.push(productId);
        heartIcon.className = 'fas fa-heart';
        e.currentTarget.classList.add('active');
        showSuccess('Produto adicionado aos favoritos!');
      }

      transaction.set(userFavoritesRef, {
        favorites: currentFavorites
      }, { merge: true });
    });

    loadUserData(user.uid);
  } catch (error) {
    console.error('Erro ao atualizar favoritos:', error);
    showError('Erro ao atualizar favoritos: ' + getFirebaseError(error.code));
  }
}

// Carrega dados do usuário (carrinho e favoritos)
async function loadUserData(userId) {
  try {
    const userDoc = await db.collection('userData').doc(userId).get();
    if (userDoc.exists) {
      const userData = userDoc.data();
      cart = userData.cart || [];
      favorites = userData.favorites || [];
      updateCartDisplay(); // Atualiza a contagem do carrinho na UI, se houver
      // Você pode re-renderizar produtos para mostrar status de favorito
      renderFeaturedProducts(); // Recarrega para refletir favoritos
      renderAllProducts(); // Recarrega para refletir favoritos
    }
  } catch (error) {
    console.error('Erro ao carregar dados do usuário:', error);
  }
}

// Atualiza a exibição da quantidade de itens no carrinho
function updateCartDisplay() {
  const cartCountElement = document.getElementById('cart-item-count');
  const cartIconBadge = document.querySelector('.cart-icon-badge'); // Novo elemento
  
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  
  if (cartCountElement) {
    cartCountElement.textContent = totalItems;
    cartCountElement.style.display = totalItems > 0 ? 'flex' : 'none';
  }
  
  // Atualizar badge no ícone do carrinho
  if (cartIconBadge) {
    cartIconBadge.textContent = totalItems;
    cartIconBadge.style.display = totalItems > 0 ? 'flex' : 'none';
  }
}

// Carrega produtos e dados do usuário quando a página é carregada
document.addEventListener('DOMContentLoaded', () => {
  auth.onAuthStateChanged((user) => {
    if (user) {
      loadUserData(user.uid).then(() => {
        loadProducts(); // Carrega produtos depois que os dados do usuário (favoritos) são carregados
      });
    } else {
      // Se não houver usuário logado, ainda assim carrega os produtos
      loadProducts();
      // Garante que o contador do carrinho esteja oculto
      updateCartDisplay();
    }
  });
});

// Event listener para o ícone do carrinho
document.getElementById('cart-icon')?.addEventListener('click', showCart);

// Mostra o carrinho como sidebar
async function showCart() {
  const user = auth.currentUser;
  if (!user) {
    showError('Por favor, faça login para ver seu carrinho.');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1500);
    return;
  }

  try {
    // Carregar dados do carrinho
    const userDoc = await db.collection('userData').doc(user.uid).get();
    const userData = userDoc.data();
    const cartItems = userData.cart || [];

    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');

    if (cartItems.length === 0) {
      cartItemsContainer.innerHTML = '<p class="empty-cart-message">Seu carrinho está vazio.</p>';
      cartTotalElement.textContent = 'R$ 0,00';
    } else {
      // Carregar detalhes dos produtos
      const productIds = cartItems.map(item => item.productId);
      const productsInCartSnapshot = await db.collection('products')
        .where(firebase.firestore.FieldPath.documentId(), 'in', productIds)
        .get();

      const productsMap = new Map();
      productsInCartSnapshot.forEach(doc => {
        productsMap.set(doc.id, doc.data());
      });

      let totalCartPrice = 0;
      cartItemsContainer.innerHTML = '';
      
      cartItems.forEach(item => {
        const product = productsMap.get(item.productId);
        if (product) {
          const itemTotalPrice = product.price * item.quantity;
          totalCartPrice += itemTotalPrice;
          
          const cartItem = document.createElement('div');
          cartItem.className = 'cart-item';
          cartItem.innerHTML = `
            <img src="${product.images[0] || 'https://via.placeholder.com/50'}" 
                 alt="${product.name}" class="cart-item-img">
            <div class="cart-item-details">
              <h4>${product.name}</h4>
              <p class="cart-item-price">R$ ${product.price.toFixed(2)}</p>
              <div class="cart-item-quantity">
                <button class="quantity-btn decrease-qty" data-id="${product.id}">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn increase-qty" data-id="${product.id}">+</button>
                <button class="remove-item" data-id="${product.id}">Remover</button>
              </div>
            </div>
          `;
          cartItemsContainer.appendChild(cartItem);
        }
      });
      
      cartTotalElement.textContent = `R$ ${totalCartPrice.toFixed(2)}`;
    }

    // Adicionar eventos
    document.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', removeFromCart);
    });

    document.querySelectorAll('.decrease-qty').forEach(btn => {
      btn.addEventListener('click', updateCartQuantity);
    });

    document.querySelectorAll('.increase-qty').forEach(btn => {
      btn.addEventListener('click', updateCartQuantity);
    });

    document.getElementById('checkout-btn')?.addEventListener('click', checkout);
    
    // Abrir sidebar
    if (window.toggleCart) {
      window.toggleCart();
    }

  } catch (error) {
    console.error('Erro ao carregar carrinho:', error);
    showError('Erro ao carregar carrinho: ' + getFirebaseError(error.code));
  }
}

// Remove produto do carrinho
async function removeFromCart(e) {
  const productId = e.target.getAttribute('data-id');
  const user = auth.currentUser;
  if (!user) return;

  try {
    const userCartRef = db.collection('userData').doc(user.uid);
    await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(userCartRef);
      const userData = doc.data() || {};
      let currentCart = userData.cart || [];

      currentCart = currentCart.filter(item => item.productId !== productId);

      transaction.set(userCartRef, {
        cart: currentCart
      }, { merge: true });
    });
    showSuccess('Produto removido do carrinho.');
    showCart(); // Recarrega o carrinho para atualizar a exibição
    loadUserData(user.uid); // Atualiza dados locais
  } catch (error) {
    console.error('Erro ao remover do carrinho:', error);
    showError('Erro ao remover do carrinho: ' + getFirebaseError(error.code));
  }
}

// Atualiza quantidade no carrinho
async function updateCartQuantity(e) {
  const productId = e.target.getAttribute('data-id');
  const action = e.target.classList.contains('increase-qty') ? 'increase' : 'decrease';
  const user = auth.currentUser;
  if (!user) return;

  try {
    const userCartRef = db.collection('userData').doc(user.uid);
    await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(userCartRef);
      const userData = doc.data() || {};
      let currentCart = userData.cart || [];

      const itemIndex = currentCart.findIndex(item => item.productId === productId);

      if (itemIndex >= 0) {
        if (action === 'increase') {
          currentCart[itemIndex].quantity += 1;
        } else if (action === 'decrease') {
          currentCart[itemIndex].quantity -= 1;
          if (currentCart[itemIndex].quantity <= 0) {
            currentCart = currentCart.filter(item => item.productId !== productId);
          }
        }
      }
      
      transaction.set(userCartRef, {
        cart: currentCart
      }, { merge: true });
    });
    
    showSuccess('Quantidade do produto atualizada.');
    showCart();
    loadUserData(user.uid);
  } catch (error) {
    console.error('Erro ao atualizar quantidade no carrinho:', error);
    showError('Erro ao atualizar quantidade: ' + getFirebaseError(error.code));
  }
}

// Finaliza compra
async function checkout() {
  const user = auth.currentUser;
  if (!user) return;

  try {
    const userDoc = await db.collection('userData').doc(user.uid).get();
    const userData = userDoc.data();
    const cartItems = userData.cart || [];

    if (cartItems.length === 0) {
      showError('Seu carrinho está vazio para finalizar a compra.');
      return;
    }

    const productIds = cartItems.map(item => item.productId);
    const productsSnapshot = await db.collection('products')
      .where(firebase.firestore.FieldPath.documentId(), 'in', productIds)
      .get();

    let orderItems = [];
    let totalOrderPrice = 0;
    const productsMap = new Map();
    productsSnapshot.forEach(doc => productsMap.set(doc.id, doc.data()));

    for (const item of cartItems) {
      const product = productsMap.get(item.productId);
      if (product) {
        orderItems.push({
          productId: item.productId,
          name: product.name,
          price: product.price,
          quantity: item.quantity,
          imageUrl: product.images[0] || ''
        });
        totalOrderPrice += product.price * item.quantity;
      }
    }

    await db.collection('orders').add({
      userId: user.uid,
      userName: userData.name || user.email,
      userEmail: user.email,
      items: orderItems,
      total: totalOrderPrice,
      status: 'Pendente',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    await db.collection('userData').doc(user.uid).update({
      cart: []
    });

    showSuccess('Compra finalizada com sucesso! Seu pedido foi registrado.');
    
    // Fechar a sidebar do carrinho
    if (window.closeCart) {
      window.closeCart();
    }
    
    loadUserData(user.uid);
    
    setTimeout(() => {
      window.location.href = 'profile.html?tab=orders';
    }, 1500);

  } catch (error) {
    console.error('Erro ao finalizar compra:', error);
    showError('Erro ao finalizar compra: ' + getFirebaseError(error.code));
  }
}

// Função auxiliar para traduzir erros do Firebase
function getFirebaseError(code) {
  const errors = {
    'permission-denied': 'Permissão negada',
    'unauthenticated': 'Usuário não autenticado',
    'not-found': 'Recurso não encontrado',
    'already-exists': 'Item já existe',
    'resource-exhausted': 'Limite de requisições excedido'
  };
  return errors[code] || `Erro: ${code}`;
}