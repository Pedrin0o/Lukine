// js/cart.js - Versão simplificada e integrada
document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const cartSidebar = document.getElementById('cart-sidebar');
    const cartOverlay = document.getElementById('cart-overlay');
    const closeCartBtn = document.querySelector('.close-cart');
    
    // Função para abrir/fechar o carrinho
    function toggleCart() {
        cartSidebar.classList.toggle('active');
        cartOverlay.classList.toggle('active');
        document.body.classList.toggle('no-scroll');
    }
    
    // Fechar carrinho
    function closeCart() {
        cartSidebar.classList.remove('active');
        cartOverlay.classList.remove('active');
        document.body.classList.remove('no-scroll');
    }
    
    // Event listeners
    closeCartBtn?.addEventListener('click', closeCart);
    cartOverlay?.addEventListener('click', closeCart);
    
    // Integrar com products.js
    window.toggleCart = toggleCart;
    window.closeCart = closeCart;
});