// admin.js - Painel administrativo

// Referências
const addProductForm = document.getElementById('add-product-form');
const productsList = document.getElementById('products-list');
const imagePreview = document.getElementById('image-preview');
const productImagesInput = document.getElementById('product-images');
const editProductModal = document.getElementById('edit-product-modal');
const editProductForm = document.getElementById('edit-product-form');
const closeEditModal = document.querySelector('.close-button');

// Verifica se usuário é admin
auth.onAuthStateChanged((user) => {
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  // Verifica se usuário é admin (você precisa implementar essa lógica)
  checkAdmin(user.uid).then(isAdmin => {
    if (!isAdmin) {
      window.location.href = '../index.html';
    } else {
      loadProducts();
      setupAdminTabs(); // Configura as abas
    }
  }).catch(error => {
    console.error('Erro ao verificar admin:', error);
    showError('Erro ao verificar permissões de administrador.');
    window.location.href = '../index.html'; // Redireciona em caso de erro na verificação
  });
});

// Função para verificar se o usuário é admin
async function checkAdmin(userId) {
  // Corrigido para buscar na coleção 'userData'
  const userDoc = await db.collection('userData').doc(userId).get();
  if (!userDoc.exists) return false; // Garante que o documento existe
  return userDoc.data().isAdmin === true; // Verifica explicitamente se isAdmin é true
}

// Carrega lista de produtos
function loadProducts() {
  db.collection('products').orderBy('createdAt', 'desc').get() // Ordena por data de criação
    .then(querySnapshot => {
      productsList.innerHTML = '';
      if (querySnapshot.empty) {
        productsList.innerHTML = '<p class="no-products-message">Nenhum produto cadastrado ainda.</p>';
        return;
      }
      querySnapshot.forEach(doc => {
        const product = doc.data();
        const productCard = document.createElement('div');
        productCard.className = 'admin-product-card';
        productCard.innerHTML = `
          <img src="${product.images[0] || 'https://via.placeholder.com/100'}" alt="${product.name}">
          <div class="product-info">
            <h3>${product.name}</h3>
            <p>R$ ${product.price.toFixed(2)}</p>
            <p>Categoria: ${product.category}</p>
            <p>Estoque: ${product.stock}</p>
            <p>Destaque: ${product.featured ? 'Sim' : 'Não'}</p>
            <div class="product-actions">
              <button class="edit-btn" data-id="${doc.id}">Editar</button>
              <button class="delete-btn" data-id="${doc.id}">Excluir</button>
            </div>
          </div>
        `;
        productsList.appendChild(productCard);
      });

      // Adiciona eventos aos botões
      document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', deleteProduct);
      });

      document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', openEditProductModal);
      });
    })
    .catch(error => {
      console.error('Erro ao carregar produtos:', error);
      showError('Erro ao carregar produtos: ' + getFirebaseError(error.code));
    });
}

// Adiciona novo produto
addProductForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const name = document.getElementById('product-name').value;
  const price = parseFloat(document.getElementById('product-price').value);
  const category = document.getElementById('product-category').value;
  const description = document.getElementById('product-description').value;
  const stock = parseInt(document.getElementById('product-stock').value);
  const featured = document.getElementById('product-featured').checked;

  if (productImagesInput.files.length === 0) {
    showError('Por favor, selecione ao menos uma imagem para o produto.');
    return;
  }

  try {
    // Faz upload das imagens
    const images = await uploadImages(productImagesInput.files);

    // Adiciona produto ao Firestore
    await db.collection('products').add({
      name,
      price,
      category,
      description,
      stock,
      featured,
      images,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    showSuccess('Produto adicionado com sucesso!');
    addProductForm.reset();
    imagePreview.innerHTML = '';
    loadProducts();
  } catch (error) {
    console.error('Erro ao adicionar produto:', error);
    showError('Erro ao adicionar produto: ' + getFirebaseError(error.code));
  }
});

// Faz upload das imagens para Firebase Storage
async function uploadImages(files) {
  const uploadPromises = [];
  const imageUrls = [];

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    // Garante que o nome do arquivo seja único para evitar sobrescrita
    const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`; // Limpa o nome do arquivo
    const fileRef = storage.ref(`products/${fileName}`); // Use a referência 'storage'

    uploadPromises.push(
      fileRef.put(file).then(snapshot => snapshot.ref.getDownloadURL())
    );
  }

  const urls = await Promise.all(uploadPromises);
  return urls;
}

// Exclui produto
function deleteProduct(e) {
  const productId = e.target.getAttribute('data-id');

  if (confirm('Tem certeza que deseja excluir este produto? Esta ação é irreversível e também removerá as imagens associadas!')) {
    db.collection('products').doc(productId).get()
      .then(doc => {
        if (doc.exists) {
          const productData = doc.data();
          const imageDeletePromises = [];

          // Exclui imagens do Storage
          if (productData.images && productData.images.length > 0) {
            productData.images.forEach(imageUrl => {
              const imageRef = storage.refFromURL(imageUrl);
              imageDeletePromises.push(imageRef.delete().catch(err => console.warn('Erro ao excluir imagem do Storage:', err))); // Loga, mas não impede a exclusão do produto
            });
          }

          return Promise.all(imageDeletePromises).then(() => {
            // Exclui o documento do Firestore
            return db.collection('products').doc(productId).delete();
          });
        }
        return Promise.resolve(); // Se o documento não existir, resolve sem fazer nada
      })
      .then(() => {
        showSuccess('Produto excluído com sucesso!');
        loadProducts();
      })
      .catch(error => {
        console.error('Erro ao excluir produto:', error);
        showError('Erro ao excluir produto: ' + getFirebaseError(error.code));
      });
  }
}

// Abre o modal de edição
async function openEditProductModal(e) {
  const productId = e.target.getAttribute('data-id');
  const doc = await db.collection('products').doc(productId).get();

  if (!doc.exists) {
    showError('Produto não encontrado para edição.');
    return;
  }

  const product = doc.data();
  editProductModal.style.display = 'block';

  // Preenche o formulário de edição
  document.getElementById('edit-product-id').value = doc.id;
  document.getElementById('edit-product-name').value = product.name;
  document.getElementById('edit-product-price').value = product.price;
  document.getElementById('edit-product-category').value = product.category;
  document.getElementById('edit-product-description').value = product.description;
  document.getElementById('edit-product-stock').value = product.stock;
  document.getElementById('edit-product-featured').checked = product.featured;

  const editImagePreview = document.getElementById('edit-image-preview');
  editImagePreview.innerHTML = '';
  if (product.images && product.images.length > 0) {
    product.images.forEach(imgSrc => {
      const img = document.createElement('img');
      img.src = imgSrc;
      img.style.maxHeight = '80px';
      img.style.margin = '5px';
      editImagePreview.appendChild(img);
    });
  }
}

// Fecha o modal de edição
closeEditModal?.addEventListener('click', () => {
  editProductModal.style.display = 'none';
});

// Fecha o modal se clicar fora dele
window.addEventListener('click', (event) => {
  if (event.target == editProductModal) {
    editProductModal.style.display = 'none';
  }
});


// Atualiza produto
editProductForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const productId = document.getElementById('edit-product-id').value;
  const name = document.getElementById('edit-product-name').value;
  const price = parseFloat(document.getElementById('edit-product-price').value);
  const category = document.getElementById('edit-product-category').value;
  const description = document.getElementById('edit-product-description').value;
  const stock = parseInt(document.getElementById('edit-product-stock').value);
  const featured = document.getElementById('edit-product-featured').checked;
  const newImagesFiles = document.getElementById('edit-product-images').files;

  try {
    let imageUrls = [];
    // Mantém imagens existentes se nenhuma nova for selecionada
    const currentProduct = await db.collection('products').doc(productId).get();
    if (currentProduct.exists) {
      imageUrls = currentProduct.data().images || [];
    }

    if (newImagesFiles.length > 0) {
      // Se novas imagens forem selecionadas, faça upload e substitua as antigas (ou adicione)
      const uploadedUrls = await uploadImages(newImagesFiles);
      // Aqui você pode decidir se quer *substituir* ou *adicionar* as imagens.
      // Para substituir: imageUrls = uploadedUrls;
      // Para adicionar: imageUrls = [...imageUrls, ...uploadedUrls];
      imageUrls = uploadedUrls; // Optei por substituir para simplicidade
    }

    await db.collection('products').doc(productId).update({
      name,
      price,
      category,
      description,
      stock,
      featured,
      images: imageUrls,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp() // Adiciona um campo de atualização
    });

    showSuccess('Produto atualizado com sucesso!');
    editProductModal.style.display = 'none';
    loadProducts();
  } catch (error) {
    console.error('Erro ao atualizar produto:', error);
    showError('Erro ao atualizar produto: ' + getFirebaseError(error.code));
  }
});


// Pré-visualização de imagens para adicionar produto
productImagesInput.addEventListener('change', () => {
  imagePreview.innerHTML = '';
  const files = productImagesInput.files;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.alt = file.name;
      img.style.maxHeight = '100px';
      img.style.margin = '5px';
      img.style.borderRadius = '5px';
      img.style.border = '1px solid #ddd';
      imagePreview.appendChild(img);
    };

    reader.readAsDataURL(file);
  }
});

// Pré-visualização de imagens para editar produto
document.getElementById('edit-product-images')?.addEventListener('change', (e) => {
  const editImagePreview = document.getElementById('edit-image-preview');
  editImagePreview.innerHTML = '';
  const files = e.target.files;

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const reader = new FileReader();

    reader.onload = (event) => {
      const img = document.createElement('img');
      img.src = event.target.result;
      img.alt = file.name;
      img.style.maxHeight = '80px';
      img.style.margin = '5px';
      img.style.borderRadius = '5px';
      img.style.border = '1px solid #ddd';
      editImagePreview.appendChild(img);
    };

    reader.readAsDataURL(file);
  }
});


// Lógica para as abas do painel administrativo
function setupAdminTabs() {
  document.querySelectorAll('.admin-tabs .tab-btn').forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');

      // Remove 'active' de todos os botões e conteúdos
      document.querySelectorAll('.admin-tabs .tab-btn').forEach(btn => btn.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

      // Adiciona 'active' ao botão clicado e ao conteúdo correspondente
      this.classList.add('active');
      document.getElementById(`${tabId}-tab`).classList.add('active');

      // Carrega conteúdo específico para a aba, se necessário
      if (tabId === 'products') {
        loadProducts();
      } else if (tabId === 'orders') {
        loadOrdersAdmin(); // Função para carregar pedidos na área admin
      }
    });
  });
}

// Exemplo de função para carregar pedidos no admin
function loadOrdersAdmin() {
  const ordersListContainer = document.getElementById('orders-list');
  if (!ordersListContainer) return; // Garante que o elemento existe

  ordersListContainer.innerHTML = '<p class="loading-message">Carregando pedidos...</p>';

  db.collection('orders').orderBy('createdAt', 'desc').get()
    .then(querySnapshot => {
      ordersListContainer.innerHTML = ''; // Limpa antes de adicionar

      if (querySnapshot.empty) {
        ordersListContainer.innerHTML = '<p class="no-products-message">Nenhum pedido realizado ainda.</p>';
        return;
      }

      querySnapshot.forEach(doc => {
        const order = doc.data();
        const orderCard = document.createElement('div');
        orderCard.className = 'admin-order-card';
        orderCard.innerHTML = `
          <h3>Pedido #${doc.id.substring(0, 8)}</h3>
          <p>Cliente: ${order.userName || order.userEmail}</p>
          <p>Data: ${new Date(order.createdAt.toDate()).toLocaleString()}</p>
          <p>Total: R$ ${order.total.toFixed(2)}</p>
          <p>Status: <span class="order-status ${order.status.toLowerCase()}">${order.status}</span></p>
          <h4>Itens do Pedido:</h4>
          <ul class="order-items-list">
            ${order.items.map(item => `
              <li>${item.name} (${item.quantity}x) - R$ ${item.price.toFixed(2)}</li>
            `).join('')}
          </ul>
          <div class="order-actions">
            <button class="update-status-btn" data-id="${doc.id}" data-current-status="${order.status}">Atualizar Status</button>
            <button class="view-details-btn" data-id="${doc.id}">Ver Detalhes</button>
          </div>
        `;
        ordersListContainer.appendChild(orderCard);
      });

      // Adicionar eventos para botões de status/detalhes dos pedidos
      document.querySelectorAll('.update-status-btn').forEach(btn => {
        btn.addEventListener('click', updateOrderStatus);
      });
      document.querySelectorAll('.view-details-btn').forEach(btn => {
        btn.addEventListener('click', viewOrderDetails);
      });
    })
    .catch(error => {
      console.error('Erro ao carregar pedidos:', error);
      showError('Erro ao carregar pedidos: ' + getFirebaseError(error.code));
    });
}

async function updateOrderStatus(e) {
  const orderId = e.target.getAttribute('data-id');
  const currentStatus = e.target.getAttribute('data-current-status');

  const newStatus = prompt(`Alterar status do pedido ${orderId}. Status atual: "${currentStatus}". Digite o novo status (Ex: Pendente, Processando, Enviado, Concluído, Cancelado):`);

  if (newStatus && newStatus.trim() !== '') {
    try {
      await db.collection('orders').doc(orderId).update({
        status: newStatus.trim(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      showSuccess('Status do pedido atualizado!');
      loadOrdersAdmin(); // Recarrega a lista de pedidos
    } catch (error) {
      console.error('Erro ao atualizar status do pedido:', error);
      showError('Erro ao atualizar status: ' + getFirebaseError(error.code));
    }
  }
}

function viewOrderDetails(e) {
  const orderId = e.target.getAttribute('data-id');
  // Implemente um modal ou redirecionamento para exibir os detalhes completos do pedido
  alert(`Exibir detalhes do pedido ${orderId}. (Implementar modal ou página dedicada)`);
  // Exemplo de como buscar os dados:
  // db.collection('orders').doc(orderId).get().then(doc => { ... });
}