// firebase-config.js - Versão corrigida
const firebaseConfig = {
  apiKey: "AIzaSyBk0tBSgMlU6yjfpiChWVv6GkB00vnOG00",
  authDomain: "lukine-joias.firebaseapp.com",
  projectId: "lukine-joias",
  storageBucket: "lukine-joias.firebasestorage.app",
  messagingSenderId: "433678915256",
  appId: "1:433678915256:web:ef0c680a3eb052cc14c64d",
};

// Inicializa o Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

// Cria as referências globais
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage(); // Adicionando referência ao Storage

// Funções globais de feedback (movidas para cá para serem acessíveis em todos os scripts)
window.showError = function(message) {
  const errorElement = document.getElementById('global-auth-error') || createGlobalErrorElement();
  errorElement.textContent = message;
  errorElement.style.display = 'block';
  errorElement.classList.add('fade-in'); // Adiciona classe para animação

  setTimeout(() => {
    errorElement.classList.remove('fade-in');
    errorElement.classList.add('fade-out'); // Adiciona classe para animação de saída
    errorElement.addEventListener('animationend', () => {
      errorElement.style.display = 'none';
      errorElement.classList.remove('fade-out');
    }, {
      once: true
    });
  }, 5000);
}

window.showSuccess = function(message) {
  const successElement = document.getElementById('global-auth-success') || createGlobalSuccessElement();
  successElement.textContent = message;
  successElement.style.display = 'block';
  successElement.classList.add('fade-in'); // Adiciona classe para animação

  setTimeout(() => {
    successElement.classList.remove('fade-in');
    successElement.classList.add('fade-out'); // Adiciona classe para animação de saída
    successElement.addEventListener('animationend', () => {
      successElement.style.display = 'none';
      successElement.classList.remove('fade-out');
    }, {
      once: true
    });
  }, 3000);
}

function createGlobalErrorElement() {
  const errorDiv = document.createElement('div');
  errorDiv.id = 'global-auth-error';
  errorDiv.className = 'global-feedback-message error-message';
  document.body.appendChild(errorDiv); // Adiciona ao body para ser global
  return errorDiv;
}

function createGlobalSuccessElement() {
  const successDiv = document.createElement('div');
  successDiv.id = 'global-auth-success';
  successDiv.className = 'global-feedback-message success-message';
  document.body.appendChild(successDiv); // Adiciona ao body para ser global
  return successDiv;
}

function getFirebaseError(code) {
  const errors = {
    'auth/email-already-in-use': 'E-mail já cadastrado',
    'auth/invalid-email': 'E-mail inválido',
    'auth/weak-password': 'Senha muito fraca (mínimo 8 caracteres)',
    'auth/user-not-found': 'Usuário não encontrado',
    'auth/wrong-password': 'Senha incorreta',
    'auth/too-many-requests': 'Muitas tentativas. Tente novamente mais tarde.',
    'auth/operation-not-allowed': 'Operação não permitida.',
    'storage/unauthorized': 'Você não tem permissão para esta ação.',
    'storage/canceled': 'Upload cancelado.',
    'storage/unknown': 'Erro desconhecido no upload.'
  };
  return errors[code] || `Erro desconhecido: ${code}`;
}