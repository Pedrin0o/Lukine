// script.js - Funções gerais de UI e interatividade

// Splash Screen (3 segundos)
document.addEventListener('DOMContentLoaded', () => {
  const splash = document.querySelector('.splash-screen');
  if (splash) {
    setTimeout(() => {
      splash.style.opacity = '0'; // Começa a transição para opacidade 0
      splash.addEventListener('transitionend', () => {
        splash.style.display = 'none'; // Esconde após a transição
      }, {
        once: true
      });
    }, 3000);
  }

  // Menu Hamburguer (Mobile)
  document.querySelector('.hamburger')?.addEventListener('click', () => {
    const navLinks = document.querySelector('.nav-links');
    if (navLinks) {
      navLinks.classList.toggle('active');
      document.body.classList.toggle('no-scroll'); // Impede rolagem do body quando menu está aberto
    }
  });

  // Fechar menu hamburguer ao clicar fora
  document.addEventListener('click', (e) => {
    const navLinks = document.querySelector('.nav-links');
    const hamburger = document.querySelector('.hamburger');
    if (navLinks && hamburger && !navLinks.contains(e.target) && !hamburger.contains(e.target) && navLinks.classList.contains('active')) {
      navLinks.classList.remove('active');
      document.body.classList.remove('no-scroll');
    }
  });


  // Slider do Banner
  const slides = document.querySelectorAll('.slider img');
  let currentSlide = 0;
  let slideInterval; // Variável para armazenar o intervalo

  if (slides.length > 0) {
    function showSlide(n) {
      slides.forEach(slide => slide.style.display = 'none');
      currentSlide = (n + slides.length) % slides.length;
      slides[currentSlide].style.display = 'block';
    }

    function nextSlide() {
      showSlide(currentSlide + 1);
    }

    // Inicializa o slider
    showSlide(0);
    slideInterval = setInterval(nextSlide, 10000); // Atribui a variável

    // Pausar/Reproduzir slider ao passar o mouse (opcional)
    const sliderContainer = document.querySelector('.slider');
    if (sliderContainer) {
      sliderContainer.addEventListener('mouseenter', () => clearInterval(slideInterval));
      sliderContainer.addEventListener('mouseleave', () => slideInterval = setInterval(nextSlide, 10000));
    }
  }


  // Newsletter Form
  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = e.target.querySelector('input[type="email"]');
      if (emailInput) {
        showSuccess(`Obrigado por assinar nossa newsletter, Pedro Gamer! E-mail registrado: ${emailInput.value}`);
        emailInput.value = ''; // Limpa o input
      }
    });
  }

  // Não é mais necessário verificar autenticação aqui, pois auth.js já faz isso.
  // if (typeof auth !== 'undefined') {
  //     auth.onAuthStateChanged((user) => {
  //         if (!user && !window.location.pathname.includes('login.html')) {
  //             window.location.href = 'login.html';
  //         }
  //     });
  // }
});