// profile.js - Página de perfil do usuário

// Referências
const userNameDisplay = document.getElementById('user-name');
const userEmailDisplay = document.getElementById('user-email');
const userBirthdateDisplay = document.getElementById('user-birthdate');
const ordersList = document.getElementById('orders-list'); // Novo elemento para pedidos


// Carrega dados do usuário (nome, email, data de nascimento)
async function loadUserProfile(userId) {
  try {
    const userDoc = await db.collection('userData').doc(userId).get();
    if (userDoc.exists) {
      const userData = userDoc.data();
      userNameDisplay.textContent = userData.name || 'Nome não definido';
      userEmailDisplay.textContent = userData.email || 'Email não definido';
      userBirthdateDisplay.textContent = userData.birthdate ? new Date(userData.birthdate).toLocaleDateString('pt-BR') : 'Data de Nascimento não definida';
    } else {
      console.warn('Documento do usuário não encontrado em userData.');
      userNameDisplay.textContent = auth.currentUser.displayName || 'Usuário';
      userEmailDisplay.textContent = auth.currentUser.email;
      userBirthdateDisplay.textContent = 'Não disponível';
    }
  } catch (error) {
    console.error('Erro ao carregar perfil do usuário:', error);
    showError('Erro ao carregar seus dados de perfil.');
  }
}


// Carrega favoritos do usuário
async function loadFavorites(userId) {
  const favoritesListContainer = document.getElementById('favorites-list');
  if (!favoritesListContainer) return; // Garante que o elemento exista

  favoritesListContainer.innerHTML = '<p class="loading-message">Carregando favoritos...</p>'; // Feedback de carregamento

  try {
    const userDoc = await db.collection('userData').doc(userId).get();
    const userData = userDoc.data();
    const favorites = userData.favorites || [];

    if (favorites.length === 0) {
      favoritesListContainer.innerHTML = '<p class="no-products-message">Você ainda não tem produtos favoritos.</p>';
      return;
    }

    // Carrega informações dos produtos favoritados
    // Usa 'where' com 'in' para buscar múltiplos IDs
    const querySnapshot = await db.collection('products')
      .where(firebase.firestore.FieldPath.documentId(), 'in', favorites)
      .get();

    favoritesListContainer.innerHTML = ''; // Limpa antes de adicionar

    querySnapshot.forEach(doc => {
      const product = doc.data();
      const productCard = document.createElement('div');
      productCard.className = 'product-card';
      productCard.innerHTML = `
        <img src="${product.images[0] || 'https://via.placeholder.com/100'}" alt="${product.name}">
        <div class="product-info">
          <h3>${product.name}</h3>
          <p>R$ ${product.price.toFixed(2)}</p>
          <div class="product-actions">
            <button class="add-to-cart primary-button" data-id="${doc.id}">Adicionar ao Carrinho</button>
            <button class="favorite-btn active" data-id="${doc.id}">
              <i class="fas fa-heart"></i>
            </button>
          </div>
        </div>
      `;
      favoritesListContainer.appendChild(productCard);
    });

    // Adiciona eventos aos botões
    document.querySelectorAll('#favorites-list .add-to-cart').forEach(btn => {
      btn.addEventListener('click', addToCart);
    });

    document.querySelectorAll('#favorites-list .favorite-btn').forEach(btn => {
      btn.addEventListener('click', toggleFavorite);
    });

  } catch (error) {
    console.error('Erro ao carregar favoritos:', error);
    showError('Erro ao carregar seus produtos favoritos: ' + getFirebaseError(error.code));
  }
}

// Carrega pedidos do usuário
async function loadOrders(userId) {
  if (!ordersList) return; // Garante que o elemento exista

  ordersList.innerHTML = '<p class="loading-message">Carregando seus pedidos...</p>';

  try {
    const querySnapshot = await db.collection('orders')
      .where('userId', '==', userId)
      .orderBy('createdAt', 'desc')
      .get();

    ordersList.innerHTML = ''; // Limpa antes de adicionar

    if (querySnapshot.empty) {
      ordersList.innerHTML = '<p class="no-products-message">Você ainda não realizou nenhum pedido.</p>';
      return;
    }

    querySnapshot.forEach(doc => {
      const order = doc.data();
      const orderCard = document.createElement('div');
      orderCard.className = 'order-card';
      orderCard.innerHTML = `
        <h3>Pedido #${doc.id.substring(0, 8)}</h3>
        <p>Data: ${new Date(order.createdAt.toDate()).toLocaleDateString('pt-BR')} ${new Date(order.createdAt.toDate()).toLocaleTimeString('pt-BR')}</p>
        <p>Total: R$ ${order.total.toFixed(2)}</p>
        <p>Status: <span class="order-status ${order.status.toLowerCase()}">${order.status}</span></p>
        <div class="order-items">
          <h4>Itens:</h4>
          <ul>
            ${order.items.map(item => `
              <li>
                <img src="${item.imageUrl || 'https://via.placeholder.com/30'}" alt="${item.name}" class="order-item-img">
                ${item.name} (${item.quantity}x) - R$ ${item.price.toFixed(2)}
              </li>
            `).join('')}
          </ul>
        </div>
        <button class="view-order-detail-btn primary-button" data-order-id="${doc.id}">Ver Detalhes</button>
      `;
      ordersList.appendChild(orderCard);
    });

    document.querySelectorAll('.view-order-detail-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const orderId = e.target.getAttribute('data-order-id');
        // Implemente a lógica para exibir detalhes do pedido, talvez em um modal
        alert(`Detalhes do Pedido: ${orderId}`);
      });
    });

  } catch (error) {
    console.error('Erro ao carregar pedidos:', error);
    showError('Erro ao carregar seus pedidos: ' + getFirebaseError(error.code));
  }
}


// Inicializa a página
auth.onAuthStateChanged(user => {
  if (!user) {
    window.location.href = 'login.html';
    return;
  }

  loadUserProfile(user.uid);

  // Lógica para as abas do perfil
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.getAttribute('data-tab');

      // Esconde todas as abas
      document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
      });

      // Remove active de todos os botões
      document.querySelectorAll('.tab-btn').forEach(tabBtn => {
        tabBtn.classList.remove('active');
      });

      // Mostra a aba selecionada
      document.getElementById(`${tabId}-tab`).classList.add('active');
      btn.classList.add('active');

      // Carrega conteúdo conforme a aba
      if (tabId === 'favorites') {
        loadFavorites(user.uid);
      } else if (tabId === 'orders') {
        loadOrders(user.uid);
      } else if (tabId === 'profile-info') {
        loadUserProfile(user.uid); // Recarrega informações do perfil
      }
    });
  });

  // Carrega a aba padrão ou a aba especificada na URL
  const urlParams = new URLSearchParams(window.location.search);
  const requestedTab = urlParams.get('tab') || 'profile-info'; // 'profile-info' como padrão

  // Ativa o botão da aba e carrega o conteúdo
  const defaultTabBtn = document.querySelector(`.tab-btn[data-tab="${requestedTab}"]`);
  if (defaultTabBtn) {
    defaultTabBtn.click(); // Simula um clique para ativar e carregar
  } else {
    // Se a aba da URL for inválida, ativa a aba de informações do perfil
    document.querySelector('.tab-btn[data-tab="profile-info"]').click();
  }
});