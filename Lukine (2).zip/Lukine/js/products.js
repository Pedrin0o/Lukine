// products.js - Gerenciamento de produtos e carrinho

// Referências globais
let products = [];
let cart = []; // Agora o carrinho será carregado do Firestore
let favorites = []; // Agora os favoritos serão carregados do Firestore

// Carrega produtos do Firestore
function loadProducts() {
  db.collection("products").orderBy('createdAt', 'desc').get() // Ordena por data de criação
    .then((querySnapshot) => {
      products = [];
      querySnapshot.forEach((doc) => {
        products.push({
          id: doc.id,
          ...doc.data()
        });
      });
      renderFeaturedProducts();
      renderAllProducts(); // Renderiza todos os produtos se houver um container para eles
    })
    .catch((error) => {
      console.error("Erro ao carregar produtos:", error);
      showError("Erro ao carregar produtos: " + getFirebaseError(error.code));
    });
}

// Renderiza produtos em destaque
function renderFeaturedProducts() {
  const featuredContainer = document.getElementById('featured-products');
  if (!featuredContainer) return;

  featuredContainer.innerHTML = '';

  const featuredProducts = products.filter(p => p.featured).slice(0, 4); // Limita a 4 produtos em destaque

  if (featuredProducts.length === 0) {
    featuredContainer.innerHTML = '<p class="no-products-message">Nenhum produto em destaque no momento.</p>';
    return;
  }

  featuredProducts.forEach(product => {
    const isFavorite = favorites.includes(product.id);
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    productCard.innerHTML = `
      <img src="${product.images[0] || 'https://via.placeholder.com/150'}" alt="${product.name}">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p class="product-price">R$ ${product.price.toFixed(2)}</p>
        <div class="product-actions">
          <button class="add-to-cart primary-button" data-id="${product.id}">Adicionar ao Carrinho</button>
          <button class="favorite-btn ${isFavorite ? 'active' : ''}" data-id="${product.id}">
            <i class="${isFavorite ? 'fas' : 'far'} fa-heart"></i>
          </button>
        </div>
      </div>
    `;
    featuredContainer.appendChild(productCard);
  });

  attachProductCardEvents();
}

// Renderiza todos os produtos (para uma página de produtos completa)
function renderAllProducts() {
  const allProductsContainer = document.getElementById('all-products-list'); // Assuma que você tem um div com esse ID
  if (!allProductsContainer) return;

  allProductsContainer.innerHTML = '';

  if (products.length === 0) {
    allProductsContainer.innerHTML = '<p class="no-products-message">Nenhum produto disponível no momento.</p>';
    return;
  }

  products.forEach(product => {
    const isFavorite = favorites.includes(product.id);
    const productCard = document.createElement('div');
    productCard.className = 'product-card';
    productCard.innerHTML = `
      <img src="${product.images[0] || 'https://via.placeholder.com/150'}" alt="${product.name}">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p class="product-category">Categoria: ${product.category}</p>
        <p class="product-price">R$ ${product.price.toFixed(2)}</p>
        <div class="product-actions">
          <button class="add-to-cart primary-button" data-id="${product.id}">Adicionar ao Carrinho</button>
          <button class="favorite-btn ${isFavorite ? 'active' : ''}" data-id="${product.id}">
            <i class="${isFavorite ? 'fas' : 'far'} fa-heart"></i>
          </button>
        </div>
      </div>
    `;
    allProductsContainer.appendChild(productCard);
  });

  attachProductCardEvents();
}

// Função para anexar eventos aos botões (reutilizável)
function attachProductCardEvents() {
  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', addToCart);
  });

  document.querySelectorAll('.favorite-btn').forEach(btn => {
    btn.addEventListener('click', toggleFavorite);
  });
}


// Adiciona produto ao carrinho
function addToCart(e) {
  const productId = e.target.getAttribute('data-id');
  const product = products.find(p => p.id === productId);

  if (!product) {
    showError('Produto não encontrado!');
    return;
  }

  const user = auth.currentUser;
  if (!user) {
    showError('Por favor, faça login para adicionar itens ao carrinho.');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1500);
    return;
  }

  // Atualiza carrinho no Firestore
  const userCartRef = db.collection('userData').doc(user.uid); // Assumindo 'userData' para carrinho e favoritos

  db.runTransaction((transaction) => {
      return transaction.get(userCartRef).then((doc) => {
        const userData = doc.data() || {};
        const currentCart = userData.cart || [];

        // Verifica se produto já está no carrinho
        const itemIndex = currentCart.findIndex(item => item.productId === productId);

        if (itemIndex >= 0) {
          // Incrementa quantidade
          currentCart[itemIndex].quantity += 1;
        } else {
          // Adiciona novo item
          currentCart.push({
            productId,
            quantity: 1
          });
        }

        transaction.set(userCartRef, {
          cart: currentCart
        }, {
          merge: true
        }); // Usa set com merge para não sobrescrever outros campos
      });
    }).then(() => {
      showSuccess('Produto adicionado ao carrinho!');
      // Atualiza o carrinho local para refletir a mudança
      loadUserData(user.uid);
    })
    .catch((error) => {
      console.error('Erro ao adicionar ao carrinho:', error);
      showError('Erro ao adicionar ao carrinho: ' + getFirebaseError(error.code));
    });
}

// Alterna favorito
function toggleFavorite(e) {
  const productId = e.currentTarget.getAttribute('data-id');
  const user = auth.currentUser;

  if (!user) {
    showError('Por favor, faça login para favoritar produtos.');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1500);
    return;
  }

  const userFavoritesRef = db.collection('userData').doc(user.uid); // Assumindo 'userData'

  db.runTransaction((transaction) => {
      return transaction.get(userFavoritesRef).then((doc) => {
        const userData = doc.data() || {};
        let currentFavorites = userData.favorites || [];
        const heartIcon = e.currentTarget.querySelector('i');

        // Verifica se já é favorito
        const favIndex = currentFavorites.indexOf(productId);

        if (favIndex >= 0) {
          // Remove dos favoritos
          currentFavorites.splice(favIndex, 1);
          heartIcon.className = 'far fa-heart'; // Coração vazio
          e.currentTarget.classList.remove('active');
          showSuccess('Produto removido dos favoritos!');
        } else {
          // Adiciona aos favoritos
          currentFavorites.push(productId);
          heartIcon.className = 'fas fa-heart'; // Coração preenchido
          e.currentTarget.classList.add('active');
          showSuccess('Produto adicionado aos favoritos!');
        }

        transaction.set(userFavoritesRef, {
          favorites: currentFavorites
        }, {
          merge: true
        });
      });
    }).then(() => {
      // Atualiza os favoritos locais após a transação
      loadUserData(user.uid);
    })
    .catch((error) => {
      console.error('Erro ao atualizar favoritos:', error);
      showError('Erro ao atualizar favoritos: ' + getFirebaseError(error.code));
    });
}

// Carrega dados do usuário (carrinho e favoritos)
async function loadUserData(userId) {
  try {
    const userDoc = await db.collection('userData').doc(userId).get();
    if (userDoc.exists) {
      const userData = userDoc.data();
      cart = userData.cart || [];
      favorites = userData.favorites || [];
      updateCartDisplay(); // Atualiza a contagem do carrinho na UI, se houver
      // Você pode re-renderizar produtos para mostrar status de favorito
      renderFeaturedProducts(); // Recarrega para refletir favoritos
      renderAllProducts(); // Recarrega para refletir favoritos
    }
  } catch (error) {
    console.error('Erro ao carregar dados do usuário:', error);
  }
}

// Função para atualizar a exibição da quantidade de itens no carrinho
function updateCartDisplay() {
  const cartCountElement = document.getElementById('cart-item-count');
  if (cartCountElement) {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountElement.textContent = totalItems;
    cartCountElement.style.display = totalItems > 0 ? 'flex' : 'none'; // Mostra/esconde o contador
  }
}

// Carrega produtos e dados do usuário quando a página é carregada
document.addEventListener('DOMContentLoaded', () => {
  auth.onAuthStateChanged((user) => {
    if (user) {
      loadUserData(user.uid).then(() => {
        loadProducts(); // Carrega produtos depois que os dados do usuário (favoritos) são carregados
      });
    } else {
      // Se não houver usuário logado, ainda assim carrega os produtos
      loadProducts();
      // Garante que o contador do carrinho esteja oculto
      updateCartDisplay();
    }
  });
});

// Event listener para o ícone do carrinho
document.getElementById('cart-icon')?.addEventListener('click', showCart);


// Função para mostrar o carrinho (agora como um modal estilizado)
async function showCart() {
  const user = auth.currentUser;
  if (!user) {
    showError('Por favor, faça login para ver seu carrinho.');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1500);
    return;
  }

  try {
    const userDoc = await db.collection('userData').doc(user.uid).get();
    const userData = userDoc.data();
    const cartItems = userData.cart || [];

    const cartModal = document.createElement('div');
    cartModal.id = 'cart-modal';
    cartModal.className = 'modal-overlay'; // Classe para escurecer o fundo

    let cartContentHtml = `
      <div class="modal-content cart-content-modal">
        <button class="close-button">&times;</button>
        <h2>Seu Carrinho</h2>
    `;

    if (cartItems.length === 0) {
      cartContentHtml += '<p class="empty-cart-message">Seu carrinho está vazio.</p>';
    } else {
      const productIds = cartItems.map(item => item.productId);
      const productsInCartSnapshot = await db.collection('products')
        .where(firebase.firestore.FieldPath.documentId(), 'in', productIds)
        .get();

      const productsMap = new Map();
      productsInCartSnapshot.forEach(doc => {
        productsMap.set(doc.id, doc.data());
      });

      let totalCartPrice = 0;
      cartContentHtml += '<div class="cart-items-container">';
      cartItems.forEach(item => {
        const product = productsMap.get(item.productId);
        if (product) {
          const itemTotalPrice = product.price * item.quantity;
          totalCartPrice += itemTotalPrice;
          cartContentHtml += `
            <div class="cart-item-card">
              <img src="${product.images[0] || 'https://via.placeholder.com/50'}" alt="${product.name}">
              <div class="item-details">
                <h4>${product.name}</h4>
                <p>R$ ${product.price.toFixed(2)} x ${item.quantity} = R$ ${itemTotalPrice.toFixed(2)}</p>
                <div class="item-actions">
                  <button class="quantity-btn decrease-qty" data-id="${product.id}">-</button>
                  <span>${item.quantity}</span>
                  <button class="quantity-btn increase-qty" data-id="${product.id}">+</button>
                  <button class="remove-from-cart" data-id="${product.id}">Remover</button>
                </div>
              </div>
            </div>
          `;
        }
      });
      cartContentHtml += `</div>
        <div class="cart-summary">
          <h3>Total do Carrinho: R$ ${totalCartPrice.toFixed(2)}</h3>
          <button id="checkout-btn" class="primary-button">Finalizar Compra</button>
        </div>
      `;
    }

    cartContentHtml += `</div>`; // Fecha modal-content
    cartModal.innerHTML = cartContentHtml;
    document.body.appendChild(cartModal);
    document.body.classList.add('no-scroll'); // Impede rolagem do body

    // Adiciona eventos ao modal
    cartModal.querySelector('.close-button').addEventListener('click', () => {
      cartModal.remove();
      document.body.classList.remove('no-scroll');
    });

    cartModal.addEventListener('click', (event) => {
      if (event.target === cartModal) {
        cartModal.remove();
        document.body.classList.remove('no-scroll');
      }
    });

    document.querySelectorAll('.remove-from-cart').forEach(btn => {
      btn.addEventListener('click', removeFromCart);
    });

    document.querySelectorAll('.decrease-qty').forEach(btn => {
      btn.addEventListener('click', updateCartQuantity);
    });
    document.querySelectorAll('.increase-qty').forEach(btn => {
      btn.addEventListener('click', updateCartQuantity);
    });

    if (cartItems.length > 0) {
      document.getElementById('checkout-btn')?.addEventListener('click', checkout);
    }

  } catch (error) {
    console.error('Erro ao carregar carrinho:', error);
    showError('Erro ao carregar carrinho: ' + getFirebaseError(error.code));
  }
}


// Remove produto do carrinho
async function removeFromCart(e) {
  const productId = e.target.getAttribute('data-id');
  const user = auth.currentUser;
  if (!user) return;

  try {
    const userCartRef = db.collection('userData').doc(user.uid);
    await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(userCartRef);
      const userData = doc.data() || {};
      let currentCart = userData.cart || [];

      currentCart = currentCart.filter(item => item.productId !== productId);

      transaction.set(userCartRef, {
        cart: currentCart
      }, {
        merge: true
      });
    });
    showSuccess('Produto removido do carrinho.');
    showCart(); // Recarrega o carrinho para atualizar a exibição
    loadUserData(user.uid); // Atualiza dados locais
  } catch (error) {
    console.error('Erro ao remover do carrinho:', error);
    showError('Erro ao remover do carrinho: ' + getFirebaseError(error.code));
  }
}

// Atualiza quantidade no carrinho
async function updateCartQuantity(e) {
  const productId = e.target.getAttribute('data-id');
  const action = e.target.classList.contains('increase-qty') ? 'increase' : 'decrease';
  const user = auth.currentUser;
  if (!user) return;

  try {
    const userCartRef = db.collection('userData').doc(user.uid);
    await db.runTransaction(async (transaction) => {
      const doc = await transaction.get(userCartRef);
      const userData = doc.data() || {};
      let currentCart = userData.cart || [];

      const itemIndex = currentCart.findIndex(item => item.productId === productId);

      if (itemIndex >= 0) {
        if (action === 'increase') {
          currentCart[itemIndex].quantity += 1;
        } else if (action === 'decrease') {
          currentCart[itemIndex].quantity -= 1;
          if (currentCart[itemIndex].quantity <= 0) {
            currentCart = currentCart.filter(item => item.productId !== productId); // Remove se quantidade for 0
          }
        }
      }
      transaction.set(userCartRef, {
        cart: currentCart
      }, {
        merge: true
      });
    });
    showSuccess('Quantidade do produto atualizada.');
    showCart(); // Recarrega o carrinho para atualizar a exibição
    loadUserData(user.uid); // Atualiza dados locais
  } catch (error) {
    console.error('Erro ao atualizar quantidade no carrinho:', error);
    showError('Erro ao atualizar quantidade: ' + getFirebaseError(error.code));
  }
}


// Finaliza compra
async function checkout() {
  const user = auth.currentUser;
  if (!user) return;

  try {
    const userDoc = await db.collection('userData').doc(user.uid).get();
    const userData = userDoc.data();
    const cartItems = userData.cart || [];

    if (cartItems.length === 0) {
      showError('Seu carrinho está vazio para finalizar a compra.');
      return;
    }

    // Carrega detalhes dos produtos para o pedido
    const productIds = cartItems.map(item => item.productId);
    const productsSnapshot = await db.collection('products')
      .where(firebase.firestore.FieldPath.documentId(), 'in', productIds)
      .get();

    let orderItems = [];
    let totalOrderPrice = 0;
    const productsMap = new Map();
    productsSnapshot.forEach(doc => productsMap.set(doc.id, doc.data()));

    for (const item of cartItems) {
      const product = productsMap.get(item.productId);
      if (product) {
        orderItems.push({
          productId: item.productId,
          name: product.name,
          price: product.price,
          quantity: item.quantity,
          imageUrl: product.images[0] || ''
        });
        totalOrderPrice += product.price * item.quantity;
      }
    }

    // Cria um novo pedido no Firestore
    await db.collection('orders').add({
      userId: user.uid,
      userName: userData.name || user.email,
      userEmail: user.email,
      items: orderItems,
      total: totalOrderPrice,
      status: 'Pendente', // Status inicial do pedido
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // Limpa o carrinho do usuário após a compra
    await db.collection('userData').doc(user.uid).update({
      cart: []
    });

    showSuccess('Compra finalizada com sucesso! Seu pedido foi registrado.');
    // Fechar o modal do carrinho
    document.getElementById('cart-modal')?.remove();
    document.body.classList.remove('no-scroll');
    loadUserData(user.uid); // Recarrega os dados do usuário, limpando o carrinho
    // Redireciona para a página de pedidos ou uma página de confirmação
    setTimeout(() => {
      window.location.href = 'profile.html?tab=orders'; // Pode redirecionar para a aba de pedidos do perfil
    }, 1500);

  } catch (error) {
    console.error('Erro ao finalizar compra:', error);
    showError('Erro ao finalizar compra: ' + getFirebaseError(error.code));
  }
}