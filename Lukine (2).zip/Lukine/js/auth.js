// auth.js - Verificação segura
if (typeof firebase === 'undefined' || !firebase.apps.length) {
  console.error('Firebase não foi carregado corretamente!');
  throw new Error('Firebase não inicializado');
}

// Verifica se auth e db existem (agora que firebase-config é carregado primeiro, devem existir)
if (typeof auth === 'undefined' || typeof db === 'undefined') {
  console.error('Serviços do Firebase não inicializados! (auth ou db)');
  // Não lançar erro aqui, pois a verificação inicial já cuida disso.
  // Pode indicar um problema no carregamento do firebase-config.js
}

// Verifica se todos os elementos necessários existem
// O uso de `?.` (optional chaining) já lida com elementos que podem não existir.
// No entanto, é bom ter certeza de que os principais formulários existem.
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const resetForm = document.getElementById('reset-form');

// Alternar entre Login e Cadastro
document.getElementById('show-register')?.addEventListener('click', (e) => {
  e.preventDefault();
  loginForm.style.display = 'none';
  registerForm.style.display = 'block';
  resetForm.style.display = 'none'; // Garante que o reset esteja escondido
  showError(''); // Limpa mensagens de erro ao trocar
  showSuccess(''); // Limpa mensagens de sucesso ao trocar
});

document.getElementById('show-login')?.addEventListener('click', (e) => {
  e.preventDefault();
  registerForm.style.display = 'none';
  loginForm.style.display = 'block';
  resetForm.style.display = 'none'; // Garante que o reset esteja escondido
  showError(''); // Limpa mensagens de erro ao trocar
  showSuccess(''); // Limpa mensagens de sucesso ao trocar
});

// Recuperação de Senha
document.getElementById('forgot-password')?.addEventListener('click', (e) => {
  e.preventDefault();
  loginForm.style.display = 'none';
  registerForm.style.display = 'none';
  resetForm.style.display = 'block';
  showError(''); // Limpa mensagens de erro ao trocar
  showSuccess(''); // Limpa mensagens de sucesso ao trocar
});

document.getElementById('back-to-login')?.addEventListener('click', (e) => {
  e.preventDefault();
  resetForm.style.display = 'none';
  loginForm.style.display = 'block';
  registerForm.style.display = 'none';
  showError(''); // Limpa mensagens de erro ao trocar
  showSuccess(''); // Limpa mensagens de sucesso ao trocar
});

// Login com Firebase
document.getElementById('login-btn')?.addEventListener('click', () => {
  const email = document.getElementById('login-email')?.value;
  const password = document.getElementById('login-password')?.value;

  if (!email || !password) {
    showError('Por favor, preencha todos os campos.');
    return;
  }

  const loginBtn = document.getElementById('login-btn');
  const originalText = loginBtn.innerHTML;
  loginBtn.disabled = true;
  loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
  showError(''); // Limpa qualquer erro anterior

  auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      showSuccess('Login realizado com sucesso! Redirecionando...');

      // Redireciona para index após 1.5 segundos
      setTimeout(() => {
        window.location.href = '../index.html';
      }, 1500);
    })
    .catch((error) => {
      showError('Erro ao fazer login: ' + getFirebaseError(error.code));
      loginBtn.disabled = false;
      loginBtn.innerHTML = originalText;
    });
});

// Cadastro com Firebase + Firestore
document.getElementById('register-btn')?.addEventListener('click', () => {
  const name = document.getElementById('register-name')?.value;
  const email = document.getElementById('register-email')?.value;
  const password = document.getElementById('register-password')?.value;
  const birthdate = document.getElementById('register-birthdate')?.value;
  const termsAccepted = document.getElementById('register-terms')?.checked;

  if (!name || !email || !password || !birthdate) {
    showError('Por favor, preencha todos os campos obrigatórios.');
    return;
  }

  if (!termsAccepted) {
    showError('Você deve aceitar os termos de uso.');
    return;
  }

  const registerBtn = document.getElementById('register-btn');
  const originalText = registerBtn.innerHTML;
  registerBtn.disabled = true;
  registerBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cadastrando...';
  showError(''); // Limpa qualquer erro anterior

  auth.createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      const user = userCredential.user;

      // Cria um documento na coleção 'userData' para informações adicionais do usuário
      return db.collection('userData').doc(user.uid).set({
        name: name,
        email: email,
        birthdate: birthdate,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        // Define isAdmin como false por padrão para novos usuários
        isAdmin: false
      });
    })
    .then(() => {
      showSuccess('Cadastro realizado com sucesso! Redirecionando para login...');

      // Redireciona para login após 2 segundos
      setTimeout(() => {
        registerForm.style.display = 'none';
        loginForm.style.display = 'block';
        registerBtn.disabled = false;
        registerBtn.innerHTML = originalText;
        registerForm.reset(); // Limpa o formulário de cadastro
      }, 2000);
    })
    .catch((error) => {
      showError('Erro ao cadastrar: ' + getFirebaseError(error.code));
      registerBtn.disabled = false;
      registerBtn.innerHTML = originalText;
    });
});

// Recuperação de Senha
document.getElementById('reset-btn')?.addEventListener('click', () => {
  const email = document.getElementById('reset-email')?.value;

  if (!email) {
    showError('Por favor, digite seu e-mail para recuperar a senha.');
    return;
  }

  auth.sendPasswordResetEmail(email)
    .then(() => {
      showSuccess(`E-mail de recuperação enviado para ${email}`);
      resetForm.style.display = 'none';
      loginForm.style.display = 'block';
      document.getElementById('reset-email').value = ''; // Limpa o campo
    })
    .catch((error) => {
      showError('Erro ao enviar e-mail: ' + getFirebaseError(error.code));
    });
});

// Verifica estado de autenticação e atualiza UI
auth.onAuthStateChanged((user) => {
  const navIcons = document.querySelector('.nav-icons'); // Certifique-se de que este elemento exista

  if (user) {
    console.log('Usuário logado:', user.email);
    updateAuthUI(user);
  } else {
    console.log('Nenhum usuário logado.');
    // Redireciona para login se não estiver em página pública
    // Adicionado uma verificação mais robusta para `window.location.pathname`
    const currentPath = window.location.pathname;
    const publicPages = ['login.html', 'register.html', 'forgot-password.html', 'index.html', 'products.html', 'contact.html', 'about.html']; // Adicione suas páginas públicas

    const isPublicPage = publicPages.some(page => currentPath.includes(page));

    if (!isPublicPage) {
      window.location.href = 'login.html';
    }
  }
});

// Funções auxiliares
function updateAuthUI(user) {
  const navIcons = document.querySelector('.nav-icons');
  if (!navIcons) return;

  // Se o usuário estiver logado, garante que o ícone de login seja removido
  // e o ícone de logout seja adicionado.
  // Evita adicionar múltiplos botões de logout.
  if (user) {
    const loginLink = document.querySelector('.nav-icons .fa-user');
    if (loginLink && loginLink.parentElement.href.includes('login.html')) {
      loginLink.parentElement.remove();
    }

    if (!document.getElementById('logout-btn')) {
      // Adiciona link para o perfil e logout
      navIcons.innerHTML += `
        <a href="profile.html" class="profile-link" title="Meu Perfil"><i class="fas fa-user-circle"></i></a>
        <a href="#" id="logout-btn" title="Sair"><i class="fas fa-sign-out-alt"></i></a>
      `;

      document.getElementById('logout-btn').addEventListener('click', (e) => {
        e.preventDefault();
        auth.signOut().then(() => {
          showSuccess('Deslogado com sucesso!');
          setTimeout(() => {
            window.location.href = 'login.html';
          }, 500); // Pequeno delay antes de redirecionar
        }).catch(error => {
          showError('Erro ao deslogar: ' + getFirebaseError(error.code));
        });
      });
    }
  } else {
    // Se o usuário não estiver logado, garante que o ícone de login exista
    // e o de logout seja removido.
    const logoutLink = document.getElementById('logout-btn');
    if (logoutLink) {
      logoutLink.remove();
    }
    const profileLink = document.querySelector('.profile-link');
    if (profileLink) {
      profileLink.remove();
    }
    if (!document.querySelector('.nav-icons .fa-user')) {
      navIcons.innerHTML += `<a href="login.html"><i class="fas fa-user"></i></a>`;
    }
  }
}