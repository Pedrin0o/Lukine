# Lukine
```
Lukine
├─ assets
│  ├─ banner
│  │  ├─ Banner.png
│  │  └─ Banner2.png
│  ├─ imagens
│  │  ├─ LogoQuadrado.png
│  │  ├─ LogoQuadrado2.png
│  │  ├─ LogoRedondo.png
│  │  ├─ LogoRedondo1.png
│  │  ├─ LogoRedondoRosa.png
│  │  ├─ LogoRedondoRosa1.png
│  │  ├─ LogoSemFundo.png
│  │  └─ LogoSemFundo2.png
│  └─ produtos
│     ├─ AnelRubi.png
│     ├─ Brinco.png
│     ├─ Colar.png
│     └─ Pulseira.png
├─ Captura de tela 2025-06-03 210118.png
├─ css
│  ├─ auth.css
│  ├─ responsive.css
│  └─ style.css
├─ index.html
├─ js
│  ├─ auth.js
│  ├─ firebase-config.js
│  ├─ products.js
│  └─ script.js
├─ login.html
├─ produtos
│  ├─ aneis.html
│  ├─ brincos.html
│  ├─ colares.html
│  ├─ correntes.html
│  ├─ pingentes.html
│  └─ pulseiras.html
└─ README.md

